This project(assignment) is created by Shreeya Bhat.
E-mail: shreeya.113-cse-16@mietjammu.in
Submitted to-Sir, Purnendu Prabhat
----------TO WHOM IT MAY CONCERN-----------
How to use this?
-just run the program and type the path.
What Problem this program is trying to solve?
-to search for specific types of files in the arbitrary directory
Content-
mp3 class and check member function to search for all mp3 files in the given directory and it's subdirectories
If there is no such files or folder, the program will return the message "not found".
Class Diagram and Mp3Finder program is included in the given directory.